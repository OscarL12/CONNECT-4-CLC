import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import javax.swing.border.*;

public class Main{

    public static void main(String[] args) {

        JFrame. setDefaultLookAndFeelDecorated(true);
        JFrame frame = new JFrame("Connect-4");
        frame.setSize(500, 650);         //resizes Pane size
        frame.setBackground(Color.WHITE);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        Connect panel = new Connect();
        frame.add(panel);
        frame.setLocationRelativeTo(null);
        frame.setVisible(true);

    }

}