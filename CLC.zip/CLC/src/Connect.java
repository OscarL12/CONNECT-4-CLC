import java.awt.*;
import java.awt.event.*;
import javax.swing.*;

public class Connect extends JPanel implements ActionListener {

    private char turn = 'x';
    private int redW = 0;
    private int blueW = 0;

    private JButton buttons[] = new JButton[42];
    private char boardStatus[] = {'u','u','u','u','u','u','u','u','u','u','u','u','u','u','u','u','u','u','u','u','u','u','u','u','u','u','u','u','u','u','u','u','u','u','u','u','u','u','u','u','u','u',};

    private Dimension squareSize = new Dimension(60,60);
    private JLabel turnPic,winLose;


    private ImageIcon red = new ImageIcon("red.png");
    private ImageIcon open = new ImageIcon("open.png");
    private ImageIcon blue = new ImageIcon("blue.png");

    private ImageIcon intro = new ImageIcon("intro (2).png");
    private ImageIcon redScreen = new ImageIcon("redwin.png");
    private ImageIcon blueScreen = new ImageIcon("blue (1).png");
    private ImageIcon instructScreen = new ImageIcon("instruct (1).png");
    Color backgroundColour = new Color(153, 153, 153);
    Color slotColour = new Color(51,153,255);
    private JPanel p_card;
    private JPanel card1, card2, card3, card4, card5;
    private CardLayout cdLayout = new CardLayout();






    public Connect(){
        p_card = new JPanel();
        p_card.setLayout(cdLayout);
        splashScreen();
        game();
        redWin();
        blueWin();
        instruct();
        setLayout(new BorderLayout());
        add("Center", p_card);
    }


    public void splashScreen(){
        card1 = new JPanel();
        card1.setBackground(backgroundColour);
        JLabel splash = new JLabel(intro);
        JButton toGame = new JButton("Continue");
        toGame.addActionListener(this);
        toGame.setActionCommand("game");
        toGame.setForeground(Color.WHITE);
        toGame.setBackground(Color.BLACK);
        card1.add(splash);
        card1.add(toGame);
        p_card.add("1", card1);
    }




    public void  game() {
        card2 = new JPanel();
        JLabel title = new JLabel("Connect 4");
        title.setFont(new Font("Arial", Font.BOLD, 60));

        JPanel gridPlay = new JPanel(new GridLayout(6, 7));
        for (int y = 0; y < 42; y++) {
            if( y == 41 || y == 40 || y == 39 || y == 38 || y == 37 || y == 36 || y == 35){
                buttons[y] = new JButton(open);
                buttons[y].setActionCommand((char) (y + 41) + "");
                buttons[y].addActionListener(this);
                buttons[y].setPreferredSize(squareSize);
                buttons[y].setBackground(slotColour);
                boardStatus[y] = 'a';
                gridPlay.add(buttons[y]);
            }
            else{
                buttons[y] = new JButton(  "");
                buttons[y].setActionCommand((char) (y + 41) + "");
                buttons[y].addActionListener(this);
                buttons[y].setPreferredSize(squareSize);
                buttons[y].setBackground(slotColour);
                gridPlay.add(buttons[y]);
            }
        }




        JPanel bottomFrame = new JPanel(new GridLayout(1,2));
        JPanel buttonSlots = new JPanel(new GridLayout(1,2));
        turnPic = new JLabel(red);
        turnPic.setBackground(backgroundColour);
        JLabel currentTurn = new JLabel("Current turn:" );
        currentTurn.setBackground(backgroundColour);
        currentTurn.setFont(new Font("Arial",Font.PLAIN,40));
        JButton reset = new JButton("Reset");
        reset.addActionListener(this);
        reset.setActionCommand("restart");
        reset.setBackground(Color.RED);
        reset.setForeground(Color.WHITE);
        reset.setPreferredSize(new Dimension(100,70));

        JButton help = new JButton("Help");
        help.addActionListener(this);
        help.setActionCommand("help");
        help.setForeground(Color.WHITE);
        help.setBackground(Color.BLUE);
        help .setPreferredSize(new Dimension(100,70));

        winLose = new JLabel("Red wins: " + redW +"  Blue wins: " +blueW);
        winLose.setFont(new Font("Arial",Font.PLAIN,30));



       bottomFrame.add(currentTurn);
       bottomFrame.add(turnPic);
       buttonSlots.add(reset);
       buttonSlots.add(help);

        card2.add(title);
        card2.add(gridPlay);
        card2.add(bottomFrame);
        card2.add(winLose);
       card2.add(buttonSlots);
        p_card.add("2", card2);
    }


    public void redWin(){
        card3 = new JPanel();
        card3.setBackground(backgroundColour);
        JLabel picWin = new JLabel(redScreen);
        JButton contGame = new JButton("Again");
        contGame.addActionListener(this);
        contGame.setActionCommand("gamenext");
        contGame.setForeground(Color.WHITE);
        contGame.setBackground(Color.BLACK);
        card3.add(picWin);
        card3.add(contGame);
        p_card.add("3",card3);
    }

    public void blueWin(){
        card4 = new JPanel();
        card4.setBackground(backgroundColour);
        JLabel picture = new JLabel(blueScreen);
        JButton nextGame = new JButton("Again");
        nextGame.addActionListener(this);
        nextGame.setActionCommand("nextgame");
        nextGame.setForeground(Color.WHITE);
        nextGame.setBackground(Color.BLACK);
        card4.add(picture);
        card4.add(nextGame);
        p_card.add("4",card4);

    }

    public void instruct(){
        card5 = new JPanel();
        card5.setBackground(backgroundColour);
        JLabel instructPic = new JLabel(instructScreen);
        JButton nextGame = new JButton("Back");
        nextGame.addActionListener(this);
        nextGame.setActionCommand("backgame");
        nextGame.setForeground(Color.WHITE);
        nextGame.setBackground(Color.BLACK);
        card5.add(instructPic);
        card5.add(nextGame);
        p_card.add("5",card5);
    }




    public void actionPerformed(ActionEvent e){

          for(int z = 0; z < 42; z++)
          {
              char symbol = ((char)(z+41));
              if(e.getActionCommand().equals(symbol + ""))
              {
                  if(validTurn(z) == true) {
                      moveChange(turn, z);
                      break;
                      }

                  }
              }

          if(e.getActionCommand().equals("restart")){
              reset();
          }
          else if(e.getActionCommand().equals("game")){
              cdLayout.show(p_card,"2");
          }
          else if(e.getActionCommand().equals("nextgame")){
              cdLayout.show(p_card,"2");
          }
          else if(e.getActionCommand().equals("gamenext")){
              cdLayout.show(p_card,"2");
          }
          else if(e.getActionCommand().equals("backgame")){
              cdLayout.show(p_card,"2");
          }
          else if(e.getActionCommand().equals("help")){
              cdLayout.show(p_card,"5");
          }
              }








    public void turnSwitch()
    {
        if(turn == 'x'){
           turn = 'o';
           turnPic.setIcon(red);
        }
       else if(turn == 'o'){
           turn = 'x';
            turnPic.setIcon(blue);
         }

       }

    public boolean validTurn(int slot)
    {
        if(boardStatus[slot] == 'a')
        {
            return true;
        }
        else
        {
            return false;
        }
    }

    public void moveChange(char currentTurn ,int slot)
    {

        turnSwitch();
        if(currentTurn == 'x'){
            if(slot == 0 || slot == 1 || slot == 2 || slot == 3 || slot == 4 || slot == 5 || slot == 6){
                boardStatus[slot] = 'b';
                buttons[slot].setIcon(blue);
            }
            else {
                boardStatus[slot] = 'b';
                buttons[slot].setIcon(blue);
                buttons[slot - 7].setIcon(open);
                boardStatus[slot-7] = 'a';
            }

        }
        else if (currentTurn == 'o'){
            if(slot == 0 || slot == 1 || slot == 2 || slot == 3 || slot == 4 || slot == 5 || slot == 6){
                boardStatus[slot] = 'r';
                buttons[slot].setIcon(red);
            }
            else {
                boardStatus[slot] = 'r';
                buttons[slot].setIcon(red);
                buttons[slot-7].setIcon(open);
                boardStatus[slot-7] = 'a';
            }

        }
        if(winCondition(slot) == true) {
            if (currentTurn == 'o') {
                reset();
                redW ++;
                winLose.setText("Red wins: " + redW +"  Blue wins: " +blueW);
                cdLayout.show(p_card, "3");
                redW++;
            } else if (currentTurn == 'x') {
                reset();
                blueW++;
                winLose.setText("Red wins: " + redW +"  Blue wins: " +blueW);
                cdLayout.show(p_card, "4");
            }
        }
            }





    public boolean winCondition(int num) {

        if(num == 0 || num == 1 || num == 2 || num == 3 ||num == 4 || num == 5 || num == 6 ){
            if(boardStatus[num] == boardStatus[num - 1] && boardStatus[num] == boardStatus[num - 2] && boardStatus[num] == boardStatus[num - 3] && boardStatus[num] != 'u' && boardStatus[num] != 'a')
                return true;
            else if(boardStatus[num] == boardStatus[num + 1] && boardStatus[num] == boardStatus[num + 2] && boardStatus[num] == boardStatus[num + 3] && boardStatus[num] != 'u' && boardStatus[num] != 'a')
                return true;
            else if(boardStatus[num] == boardStatus[num + 7] && boardStatus[num] == boardStatus[num + 14] && boardStatus[num] == boardStatus[num +21] && boardStatus[num] != 'u' && boardStatus[num] != 'a')
                return true;
            else if(boardStatus[num] == boardStatus[num + 8] && boardStatus[num] == boardStatus[num + 16] && boardStatus[num] == boardStatus[num + 24] && boardStatus[num] != 'u' && boardStatus[num] != 'a')
                return true;
            else if(boardStatus[num] == boardStatus[num + 6] && boardStatus[num] == boardStatus[num + 12] && boardStatus[num] == boardStatus[num + 18] && boardStatus[num] != 'u' && boardStatus[num] != 'a')
                return true;
            else
                return false;
        }

        else {
            if (boardStatus[num] == boardStatus[num - 1] && boardStatus[num] == boardStatus[num - 2] && boardStatus[num] == boardStatus[num - 3] && boardStatus[num] != 'u' && boardStatus[num] != 'a')
                return true;
            else if (boardStatus[num] == boardStatus[num + 1] && boardStatus[num] == boardStatus[num + 2] && boardStatus[num] == boardStatus[num + 3] && boardStatus[num] != 'u' && boardStatus[num] != 'a')
                return true;
            else if (boardStatus[num] == boardStatus[num + 7] && boardStatus[num] == boardStatus[num + 14] && boardStatus[num] == boardStatus[num + 21] && boardStatus[num] != 'u' && boardStatus[num] != 'a')
                return true;
            else if (boardStatus[num] == boardStatus[num - 7] && boardStatus[num] == boardStatus[num - 14] && boardStatus[num] == boardStatus[num - 21] && boardStatus[num] != 'u' && boardStatus[num] != 'a')
                return true;
            else if (boardStatus[num] == boardStatus[num + 8] && boardStatus[num] == boardStatus[num + 16] && boardStatus[num] == boardStatus[num + 24] && boardStatus[num] != 'u' && boardStatus[num] != 'a')
                return true;
            else if (boardStatus[num] == boardStatus[num - 8] && boardStatus[num] == boardStatus[num - 16] && boardStatus[num] == boardStatus[num - 24] && boardStatus[num] != 'u' && boardStatus[num] != 'a')
                return true;
            else if (boardStatus[num] == boardStatus[num + 6] && boardStatus[num] == boardStatus[num + 12] && boardStatus[num] == boardStatus[num + 18] && boardStatus[num] != 'u' && boardStatus[num] != 'a')
                return true;
            else if (boardStatus[num] == boardStatus[num - 6] && boardStatus[num] == boardStatus[num - 12] && boardStatus[num] == boardStatus[num - 18] && boardStatus[num] != 'u' && boardStatus[num] != 'a')
                return true;
            else
                return false;
        }
    }



    public void reset(){
        for (int y = 0; y < 42; y++) {
            if( y == 41 || y == 40 || y == 39 || y == 38 || y == 37 || y == 36 || y == 35){
                buttons[y].setIcon(open);
                boardStatus[y] = 'a';
            }
            else{
                buttons[y].setIcon(null);
                boardStatus[y] = 'u';
            }

        }
    }













    protected static ImageIcon createImageIcon(String path) {

        java.net.URL imgURL = Connect.class.getResource(path);
        if (imgURL != null) {
            return new ImageIcon(imgURL);
        } else {
            System.err.println("Couldn't find file: " + path);
            return null;
        }
    }


}

